* # File name: /local-scratch/localhome/escmc38/Desktop/ensc450/CDS/nor/nor/
# hspiceS/schematic/netlist/nor.c.raw
# Netlist output for hspiceS.
# Generated on Mar 9 18:55:56 2021

# global net definitions
.GLOBAL VDD! GND!
USE nor_nor_schematic


USEM nch nch
USEM pch pch

# Include files






# End of Netlist
