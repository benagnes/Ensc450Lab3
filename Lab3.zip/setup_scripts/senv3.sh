source /etc/profile.d/ensc-cmc.csh
source /CMC/setups/CDS_setup.csh
cd /local-scratch/localhome/escmc38/Desktop/ensc450/CDS
