* # File name: /local-scratch/localhome/escmc38/Desktop/ensc450/CDS/
# inverter_unskewed/inv/hspiceS/schematic/netlist/inv.c.raw
# Netlist output for hspiceS.
# Generated on Mar 8 15:59:29 2021

# global net definitions
.GLOBAL GND! VDD!
USE inverter_unskewed_inv_schematic


USEM nch nch
USEM pch pch

# Include files






# End of Netlist
