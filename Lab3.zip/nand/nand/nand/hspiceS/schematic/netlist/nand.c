* # File name: /local-scratch/localhome/escmc38/Desktop/ensc450/CDS/nand/
# nand/nand/hspiceS/schematic/netlist/nand.c.raw
# Netlist output for hspiceS.
# Generated on Mar 10 18:37:52 2021

# global net definitions
.GLOBAL VDD! GND!
USE nand_nand_schematic


USEM nch nch
USEM pch pch

# Include files






# End of Netlist
