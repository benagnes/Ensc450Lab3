* # File name: /local-scratch/localhome/escmc38/Desktop/ensc450/CDS/xor/
# xor_extracted/xor/hspiceS/extracted/netlist/xor.c.raw
# Netlist output for hspiceS.
# Generated on Mar 13 18:48:53 2021

USE xor_xor_extracted


USEM nch nch
USEM pch pch

# Include files






# End of Netlist
