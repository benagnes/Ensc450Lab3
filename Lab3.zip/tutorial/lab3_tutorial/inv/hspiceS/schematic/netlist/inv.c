* # File name: /local-scratch/localhome/escmc38/Desktop/ensc450/CDS/
# lab3_tutorial/inv/hspiceS/schematic/netlist/inv.c.raw
# Netlist output for hspiceS.
# Generated on Feb 28 17:10:02 2021

# global net definitions
.GLOBAL GND! VDD!
USE inverter_inv_schematic


USEM nch nch
USEM pch pch

# Include files






# End of Netlist
