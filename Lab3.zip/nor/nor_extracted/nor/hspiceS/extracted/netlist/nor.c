* # File name: /local-scratch/localhome/escmc38/Desktop/ensc450/CDS/nor/
# nor_extracted/nor/hspiceS/extracted/netlist/nor.c.raw
# Netlist output for hspiceS.
# Generated on Mar 9 22:27:23 2021

USE nor_nor_extracted


USEM nch nch
USEM pch pch

# Include files






# End of Netlist
