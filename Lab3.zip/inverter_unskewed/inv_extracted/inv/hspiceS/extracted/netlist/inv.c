* # File name: /local-scratch/localhome/escmc38/Desktop/ensc450/CDS/
# inverter_unskewed/inv_extracted/inv/hspiceS/extracted/netlist/inv.c.raw
# Netlist output for hspiceS.
# Generated on Mar 10 00:59:12 2021

USE inverter_unskewed_inv_extracted


USEM nch nch
USEM pch pch

# Include files






# End of Netlist
