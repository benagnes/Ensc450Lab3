* # File name: /local-scratch/localhome/escmc38/Desktop/ensc450/CDS/xor/xor/
# xor/hspiceS/schematic/netlist/xor.c.raw
# Netlist output for hspiceS.
# Generated on Mar 13 15:38:55 2021

# global net definitions
.GLOBAL VDD! GND!
USE xor_xor_schematic


USEM nch nch
USEM pch pch

# Include files






# End of Netlist
