* # File name: /local-scratch/localhome/escmc38/Desktop/ensc450/CDS/
# lab3_tutorial_extracted/inv/hspiceS/extracted/netlist/inv.c.raw
# Netlist output for hspiceS.
# Generated on Mar 3 19:05:15 2021

USE inverter_inv_extracted


USEM nch nch
USEM pch pch

# Include files






# End of Netlist
