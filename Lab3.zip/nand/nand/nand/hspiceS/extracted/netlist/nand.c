* # File name: /local-scratch/localhome/escmc38/Desktop/ensc450/CDS/nand/
# nand/nand/hspiceS/extracted/netlist/nand.c.raw
# Netlist output for hspiceS.
# Generated on Mar 10 18:44:08 2021

USE nand_nand_extracted


USEM nch nch
USEM pch pch

# Include files






# End of Netlist
